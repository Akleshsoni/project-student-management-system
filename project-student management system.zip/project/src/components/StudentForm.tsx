import React, { useState, useEffect } from 'react';
import { Student, Month } from '../types';

interface StudentFormProps {
  addStudent: (student: Student) => void;
  updateStudent: (student: Student) => void;
  deleteStudent: (id: number) => void;
  selectedStudent: Student | null;
  clearSelection: () => void;
}

const StudentForm: React.FC<StudentFormProps> = ({ 
  addStudent, 
  updateStudent,
  deleteStudent,
  selectedStudent, 
  clearSelection 
}) => {
  const [id, setId] = useState<number>(0);
  const [name, setName] = useState<string>('');
  const [classValue, setClassValue] = useState<string>('');
  const [batch, setBatch] = useState<string>('');
  const [admitDate, setAdmitDate] = useState<string>('');
  const [mobile, setMobile] = useState<string>('');
  const [parentMobile, setParentMobile] = useState<string>('');
  const [payMonth, setPayMonth] = useState<Month>('jan');
  const [payAmount, setPayAmount] = useState<string>('');

  useEffect(() => {
    if (selectedStudent) {
      setId(selectedStudent.id);
      setName(selectedStudent.name);
      setClassValue(selectedStudent.class);
      setBatch(selectedStudent.batch);
      setAdmitDate(selectedStudent.admitDate);
      setMobile(selectedStudent.mobile);
      setParentMobile(selectedStudent.parentMobile);
    }
  }, [selectedStudent]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!id || !name || !classValue) {
      alert('Serial Number, Name, and Class are required!');
      return;
    }

    const payments = selectedStudent?.payments || {};
    
    if (payMonth && payAmount) {
      payments[payMonth] = payAmount;
    }

    const studentData: Student = {
      id,
      name,
      class: classValue,
      batch,
      admitDate,
      mobile,
      parentMobile,
      payments
    };

    if (selectedStudent) {
      updateStudent(studentData);
    } else {
      addStudent(studentData);
    }

    clearForm();
  };

  const handleDelete = () => {
    if (window.confirm('Are you sure you want to delete this record?')) {
      if (selectedStudent) {
        deleteStudent(selectedStudent.id);
      }
      clearForm();
    }
  };

  const clearForm = () => {
    setId(0);
    setName('');
    setClassValue('');
    setBatch('');
    setAdmitDate('');
    setMobile('');
    setParentMobile('');
    setPayMonth('jan');
    setPayAmount('');
    clearSelection();
  };

  return (
    <div className="bg-blue-100 p-4 rounded-lg shadow-md">
      <h2 className="text-xl font-bold mb-4 text-center">Manage Students</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="block font-bold mb-1">Serial No</label>
          <input
            type="number"
            value={id}
            onChange={(e) => setId(parseInt(e.target.value) || 0)}
            className="w-full p-2 border rounded"
            required
          />
        </div>

        <div className="mb-3">
          <label className="block font-bold mb-1">Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full p-2 border rounded"
            required
          />
        </div>

        <div className="mb-3">
          <label className="block font-bold mb-1">Class</label>
          <select
            value={classValue}
            onChange={(e) => setClassValue(e.target.value)}
            className="w-full p-2 border rounded"
            required
          >
            <option value="">Select Class</option>
            <option value="Class 1">Class 1</option>
            <option value="Class 2">Class 2</option>
            <option value="Class 3">Class 3</option>
            <option value="Class 4">Class 4</option>
            <option value="Class 5">Class 5</option>
            <option value="Class 6">Class 6</option>
            <option value="Class 7">Class 7</option>
            <option value="Class 8">Class 8</option>
            <option value="Class 9">Class 9</option>
            <option value="Class 10">Class 10</option>
          </select>
        </div>

        <div className="mb-3">
          <label className="block font-bold mb-1">Batch Name</label>
          <input
            type="text"
            value={batch}
            onChange={(e) => setBatch(e.target.value)}
            className="w-full p-2 border rounded"
          />
        </div>

        <div className="mb-3">
          <label className="block font-bold mb-1">Payment Date</label>
          <input
            type="date"
            value={admitDate}
            onChange={(e) => setAdmitDate(e.target.value)}
            className="w-full p-2 border rounded"
          />
        </div>

        <div className="mb-3">
          <label className="block font-bold mb-1">Mobile</label>
          <input
            type="text"
            value={mobile}
            onChange={(e) => setMobile(e.target.value)}
            className="w-full p-2 border rounded"
          />
        </div>

        <div className="mb-3">
          <label className="block font-bold mb-1">Parents Mobile</label>
          <input
            type="text"
            value={parentMobile}
            onChange={(e) => setParentMobile(e.target.value)}
            className="w-full p-2 border rounded"
          />
        </div>

        <div className="mb-3 flex items-center space-x-2">
          <label className="font-bold">Pay Amount:</label>
          <select
            value={payMonth}
            onChange={(e) => setPayMonth(e.target.value as Month)}
            className="p-2 border rounded"
          >
            <option value="jan">January</option>
            <option value="feb">February</option>
            <option value="mar">March</option>
            <option value="apr">April</option>
            <option value="may">May</option>
            <option value="jun">June</option>
            <option value="jul">July</option>
            <option value="aug">August</option>
            <option value="sep">September</option>
            <option value="oct">October</option>
            <option value="nov">November</option>
            <option value="dec">December</option>
          </select>
          <input
            type="text"
            value={payAmount}
            onChange={(e) => setPayAmount(e.target.value)}
            className="p-2 border rounded w-24"
            placeholder="Amount"
          />
        </div>

        <div className="flex justify-between mt-4">
          <button
            type="submit"
            className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
          >
            {selectedStudent ? 'Update' : 'Add'}
          </button>
          <button
            type="button"
            onClick={clearForm}
            className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
          >
            Clear
          </button>
          {selectedStudent && (
            <button
              type="button"
              onClick={handleDelete}
              className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
            >
              Delete
            </button>
          )}
        </div>
      </form>
    </div>
  );
};

export default StudentForm;