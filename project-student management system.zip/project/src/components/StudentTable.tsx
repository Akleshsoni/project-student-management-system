import React from 'react';
import { Student } from '../types';

interface StudentTableProps {
  students: Student[];
  onSelectStudent: (student: Student) => void;
  searchBy: string;
  searchText: string;
  setSearchBy: (value: string) => void;
  setSearchText: (value: string) => void;
  handleSearch: () => void;
  clearSearch: () => void;
}

const StudentTable: React.FC<StudentTableProps> = ({
  students,
  onSelectStudent,
  searchBy,
  searchText,
  setSearchBy,
  setSearchText,
  handleSearch,
  clearSearch
}) => {
  const months = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  return (
    <div className="bg-blue-100 p-4 rounded-lg shadow-md">
      <div className="flex items-center mb-4 space-x-2">
        <label className="font-bold">Search By:</label>
        <select
          value={searchBy}
          onChange={(e) => setSearchBy(e.target.value)}
          className="p-2 border rounded"
        >
          <option value="id">Serial No</option>
          <option value="name">Name</option>
          <option value="class">Class</option>
        </select>
        <input
          type="text"
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
          className="p-2 border rounded flex-grow"
          placeholder="Search..."
        />
        <button
          onClick={handleSearch}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        >
          Search
        </button>
        <button
          onClick={clearSearch}
          className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
        >
          Show All
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full bg-white border">
          <thead>
            <tr className="bg-gray-200">
              <th className="border p-2">Sl.No</th>
              <th className="border p-2">Name</th>
              <th className="border p-2">Class</th>
              <th className="border p-2">Batch</th>
              <th className="border p-2">Admit Date</th>
              <th className="border p-2">Mobile</th>
              <th className="border p-2">Parents Mobile</th>
              {monthNames.map((month, index) => (
                <th key={index} className="border p-2">{month}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {students.map((student) => (
              <tr 
                key={student.id} 
                onClick={() => onSelectStudent(student)}
                className="hover:bg-gray-100 cursor-pointer"
              >
                <td className="border p-2">{student.id}</td>
                <td className="border p-2">{student.name}</td>
                <td className="border p-2">{student.class}</td>
                <td className="border p-2">{student.batch}</td>
                <td className="border p-2">{student.admitDate}</td>
                <td className="border p-2">{student.mobile}</td>
                <td className="border p-2">{student.parentMobile}</td>
                {months.map((month) => (
                  <td key={month} className="border p-2">
                    {student.payments[month] || ''}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default StudentTable;