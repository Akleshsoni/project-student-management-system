import React, { useState, useEffect } from 'react';
import { Student } from './types';
import StudentForm from './components/StudentForm';
import StudentTable from './components/StudentTable';
import { GraduationCap } from 'lucide-react';

function App() {
  const [students, setStudents] = useState<Student[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [searchBy, setSearchBy] = useState<string>('id');
  const [searchText, setSearchText] = useState<string>('');
  const [filteredStudents, setFilteredStudents] = useState<Student[]>([]);

  // Load data from localStorage on component mount
  useEffect(() => {
    const savedStudents = localStorage.getItem('students');
    if (savedStudents) {
      setStudents(JSON.parse(savedStudents));
      setFilteredStudents(JSON.parse(savedStudents));
    }
  }, []);

  // Save data to localStorage whenever students change
  useEffect(() => {
    localStorage.setItem('students', JSON.stringify(students));
    setFilteredStudents(students);
  }, [students]);

  const addStudent = (student: Student) => {
    // Check if student with same ID already exists
    if (students.some(s => s.id === student.id)) {
      alert('A student with this Serial Number already exists!');
      return;
    }
    setStudents([...students, student]);
  };

  const updateStudent = (updatedStudent: Student) => {
    setStudents(students.map(student => 
      student.id === updatedStudent.id ? updatedStudent : student
    ));
    setSelectedStudent(null);
  };

  const deleteStudent = (id: number) => {
    setStudents(students.filter(student => student.id !== id));
    setSelectedStudent(null);
  };

  const handleSearch = () => {
    if (!searchText.trim()) {
      setFilteredStudents(students);
      return;
    }

    const filtered = students.filter(student => {
      const searchValue = searchText.toLowerCase();
      
      if (searchBy === 'id') {
        return student.id.toString().includes(searchValue);
      } else if (searchBy === 'name') {
        return student.name.toLowerCase().includes(searchValue);
      } else if (searchBy === 'class') {
        return student.class.toLowerCase().includes(searchValue);
      }
      
      return false;
    });
    
    setFilteredStudents(filtered);
  };

  const clearSearch = () => {
    setSearchText('');
    setFilteredStudents(students);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-blue-800 text-white p-4 shadow-md">
        <div className="container mx-auto flex items-center justify-center">
          <GraduationCap size={36} className="mr-2" />
          <h1 className="text-3xl font-bold">Student Management System</h1>
        </div>
      </header>

      <main className="container mx-auto py-6 px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1">
            <StudentForm 
              addStudent={addStudent} 
              updateStudent={updateStudent}
              deleteStudent={deleteStudent}
              selectedStudent={selectedStudent}
              clearSelection={() => setSelectedStudent(null)}
            />
          </div>
          <div className="md:col-span-2">
            <StudentTable 
              students={filteredStudents}
              onSelectStudent={setSelectedStudent}
              searchBy={searchBy}
              searchText={searchText}
              setSearchBy={setSearchBy}
              setSearchText={setSearchText}
              handleSearch={handleSearch}
              clearSearch={clearSearch}
            />
          </div>
        </div>
      </main>

      <footer className="bg-blue-800 text-white p-3 text-center">
        <p>Student Management System - React Version</p>
      </footer>
    </div>
  );
}

export default App;