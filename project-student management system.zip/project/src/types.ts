export interface Student {
  id: number;
  name: string;
  class: string;
  batch: string;
  admitDate: string;
  mobile: string;
  parentMobile: string;
  urlName?: string; // Added URL name field
  payments: {
    jan?: string;
    feb?: string;
    mar?: string;
    apr?: string;
    may?: string;
    jun?: string;
    jul?: string;
    aug?: string;
    sep?: string;
    oct?: string;
    nov?: string;
    dec?: string;
  };
}

export type Month = 'jan' | 'feb' | 'mar' | 'apr' | 'may' | 'jun' | 'jul' | 'aug' | 'sep' | 'oct' | 'nov' | 'dec';